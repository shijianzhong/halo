var HaloConsoleShared=function(e){"use strict";function n(u){return u}return e.definePlugin=n,Object.defineProperty(e,"__esModule",{value:!0}),e}({});
//# sourceMappingURL=halo-console-shared.iife.js.map
